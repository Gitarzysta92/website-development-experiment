# Implementation plan AF-D1

Revision `1.0`, 9 October 2026. Owner: autonomous executor. Contract state: **complete for the local experiment**. Package acceptance: **accepted within AF-EP-1.0** after the [compilation checks](compilation-validation.json). Implementation progress: **not started**.

## Scope and sources

Implement the full bilingual local website, design/content/assets, selected form and receiver adapters, visibility and privacy boundaries, verification, recovery instructions and handover. Live delivery, public release, DNS changes, paid commitments and recurring operation are not authorized by this package. Remaining business/owner approvals remain explicit in [AF-DEC-1.0](decisions.md).

Sources: HP-1.1 with PREP-1.0 / SM-0.3 / DR-1.0 and original EP-1.0; guideline commit `f8cb8faf680bde5d194258387543d1e5ebd544dc`; AF-SPEC-1.0, AF-STRUCT-1.0, AF-CHECK-1.0, AF-DEC-1.0 / AF-EP-1.0. Exact source and file identities are in [source-lock.json](source-lock.json) and the [package manifest](../package-manifest.json).

Baseline: the input package contains no application. Planned code lives in `website/`. If a run starts with existing implementation, inspect it and determine whether it matches this scope before changing it; do not assume earlier passes apply. This plan's [solution structure](solution-structure.md) is the sole planned module map. Runtime implementation documentation records its actual realization.

Compilation performed creation-workflow stages 1–2 and compile-implementation-units stages 1–6. Execution units specialize creation stages 3–7 and add-page-or-feature stages 2–4. Creation stage 6 is limited to release preparation and an explicit not-published handoff. No unit deploys or activates ongoing operation. Execution follows the pinned [implementation workflow](../knowledge/website-creation-guidelines/implementation/execute-implementation-plan.md), stages 1–6, for already defined units.

## Objective coverage

| Source objective | Selected local outcome / qualification | Structural targets | Units and planned checks |
| --- | --- | --- | --- |
| OBJ-01 | Complete traceable EN/PL drafts with accurate maturity and review state; human approval remains pending | E-02/E-06/E-12 | IU-02/04/05/07; C-02/C-14 |
| OBJ-02 | All selected pages, project/global navigation, contextual links and direct-entry context | E-03/E-05/E-06 | IU-02/03/04/05/07/08; C-03/C-09/C-10 |
| OBJ-03 | Equivalent EN/PL routes, UI, copy and metadata; no automatic override of explicit language | E-02/E-03/E-05/E-09/E-10 | IU-02/03/04/05/07/08; C-02/C-03/C-06/C-10 |
| OBJ-04 | Shared responsive visual system and meaningful templates from supplied palette/references | E-04/E-05/E-06/E-10 | IU-03/04/05/07; C-04/C-05/C-06 |
| OBJ-05 | Form, email alternative, test-receiver receipt and concrete provider adapter; real delivery remains gated | E-07/E-08/E-10 | IU-06/07/09; C-07/C-08/C-09 |
| OBJ-06 | Preview isolation, production metadata contract, sitemap/publication gates and known migration routes | E-02/E-03/E-09 | IU-02/08/09; C-03/C-10/C-11 |
| OBJ-07 | Reproducible tooling, content editing, configuration boundaries and contributor map | E-01/E-02/E-07/E-08/E-11/E-12 | IU-01/02/06/09/10; C-01/C-13/C-14/C-15 |
| OBJ-08 | Actual local data notice, validation/abuse/failure controls, synthetic isolation and no payload leakage | E-07/E-08/E-09/E-10 | IU-06/07/08/09; C-07/C-08/C-11 |
| OBJ-09 | Evidence for all local combined journeys and representative failure states; no invented verification | E-11/E-12 and all consumers | IU-09 plus each producing unit; C-01 through C-15 as applicable |
| OBJ-10 | Reproducible local recovery and release/operating handover; production destination remains unselected | E-01/E-12 | IU-10; C-14/C-15 |

Every numbered guideline rule has an explicit applicability row in [rule-coverage.csv](rule-coverage.csv). Applicable obligations map to structural targets, an owning unit/output and a planned check. Unselected capability rules are excluded with reasons. There is no inherited evidence of website compliance and no accepted waiver of a required local check.

## Complete unit manifest and order

The machine-readable [unit manifest](unit-manifest.json) is a component of this plan. It binds the following exact revision `1.0` unit prompts. All units are owned by the execution agent. They are contracts for work on structural elements, not a second task layer.

| Order | Unit prompt | Concrete output contract | Dependencies |
| --- | --- | --- | --- |
| 1 | [IU-01: Foundation](units/01-foundation.md) | IU-01.O1: pinned runnable project/configuration/public API boundaries and command foundations | Input and compiled package; runtime/package access |
| 2 | [IU-02: Content and routes](units/02-content-and-routes.md) | IU-02.O1: validated 34-route content draft set, shared facts, public projections and navigation API | IU-01.O1 |
| 3 | [IU-03: Design and shell](units/03-design-and-shell.md) | IU-03.O1: tokens/components/chrome, representative EN/PL page and responsive design evidence | IU-01.O1, IU-02.O1 |
| 4 | [IU-04: Company pages](units/04-company-pages.md) | IU-04.O1: six company/index page identities in both languages | IU-02.O1, IU-03.O1 |
| 5 | [IU-05: Project pages](units/05-project-pages.md) | IU-05.O1: nine project overview/detail identities in both languages | IU-02.O1, IU-03.O1 |
| 6 | [IU-06: Enquiry service](units/06-enquiry-service.md) | IU-06.O1: validated use case, endpoint, three adapters, synthetic receiver and contract tests | IU-01.O1, IU-02.O1 |
| 7 | [IU-07: Contact and privacy](units/07-contact-and-privacy.md) | IU-07.O1: two remaining page identities in both languages, integrated form and truthful notice | IU-02.O1, IU-03.O1, IU-06.O1 |
| 8 | [IU-08: Visibility and integration](units/08-visibility-and-integration.md) | IU-08.O1: 34-route integrated artifact, metadata/gates/headers/redirects and checks | IU-04.O1, IU-05.O1, IU-07.O1 |
| 9 | [IU-09: Verification and repair](units/09-verification-and-repair.md) | IU-09.O1: verified/repaired local implementation and scoped actual acceptance evidence | IU-08.O1 |
| 10 | [IU-10: Handover](units/10-handover.md) | IU-10.O1: reproducible runbook, local recovery evidence and final status/remaining prerequisites | IU-09.O1 |

Unit contracts are complete even though their dependency outputs do not yet exist. All producer/consumer contracts are bound to this plan revision. A producer output becomes eligible input after its own output checks pass, with actual implementation version recorded. The same executor supplies all local outputs; the experiment operator supplies runtime/network permissions when the environment requires them. No live credentials are prerequisites to local implementation.

Execute units in the listed sequence to keep code changes and experiment records straightforward. No parallel-agent work is prescribed. Shared owners: IU-02 owns content/route schemas; IU-03 owns reusable visual/shell contracts; IU-06 owns enquiry contracts; IU-08 integrates shared metadata/headers; IU-09 repairs their implementations without silently changing contracts. Later changes to a shared owner must recheck its affected consumers. Ordinary repairs may touch earlier unit-owned files and are logged against those contracts.

## Integration checkpoints

| ID | When / inputs | Required combined observation | Record |
| --- | --- | --- | --- |
| CP-01 | After IU-02; project + content/route API | Reproducible build foundations, complete bilingual inventory, schema rejects broken identities/relationships, no source/private-data export | C-01/C-02/C-03/C-13; acceptance report |
| CP-02 | After IU-03; representative page + shell/components | EN/PL representative route, global/project links, keyboard/mobile states and visual direction function together | C-03/C-04/C-05/C-06; rendered screenshots and report |
| CP-03 | After IU-07; all page groups + enquiry | All 34 pages exist; investor/partner/demo context reaches editable form; local receiver really accepts one synthetic submission; failures recover truthfully | C-02/C-03/C-07/C-08/C-09; report with local-only receipt evidence |
| CP-04 | After IU-08; integrated build | Route/metadata/redirect/publication/privacy/configuration behavior agrees across pages, assets and endpoint | C-10/C-11/C-13/C-14; report |
| CP-05 | After IU-09; repaired full artifact | Required representative browser checks, performance budgets, content/design review and prior affected checks pass | C-01 through C-14; report and saved artifacts |
| CP-06 | After IU-10; implementation + evidence + runbook | Commands and local recovery reproduced; objective/rule evidence accounted for; factual launch limitations assigned | C-14/C-15; final handover |

The executor evaluates each checkpoint autonomously. Checkpoints are not operator approval pauses. Record defects and repair them under the same contracts. If a genuine environment dependency blocks a check, continue independent work and retain the actual gap.

## Completion and evidence ownership

Unit completion requires its contracted outputs and checks, not merely actions attempted. Plan completion requires all ten units, all required local checks and combined checkpoints, full objective coverage, and a usable locally runnable handover. A blocked required local check means verification/whole-plan completion remains incomplete, even if all source code is present.

At run start, copy the [execution record seed](execution-record.md) and [acceptance report seed](acceptance-report.md) into `website/docs/`. Progress belongs to the execution record; check outcomes belong to the acceptance report; this plan owns unit inventory/order and package acceptance. Save raw evidence under `website/artifacts/`. Record a source/content/configuration fingerprint or Git revision where available; do not invent Git metadata.

The final response must state local startup instructions and distinguish implemented work, verification, isolated provider tests, local test delivery, pending human review, live delivery and publication. No deployment receipt, real lead, scheduled monitor or mailbox delivery is claimed by this plan.

## Completeness and acceptance

Review date: 9 October 2026. Reviewer/compiler: assistant acting under AF-EP-1.0. Gate scope: AF-D1 revision 1.0 and all ten unit revisions 1.0 against the locked source inputs/library.

The [compilation validation record](compilation-validation.json) records actual checks for file/reference integrity, rule coverage, objective ownership, route inventory, complete unit fields, dependency/order consistency, and protected source files. The manual review checks project-specific constraints, bounded future outputs, source-proposal resolutions, and separate live-release prerequisites. No consequential local definition gap remains; external production definitions are explicitly outside this package's release scope.

Acceptance is **autonomous acceptance of the complete local package**, not human approval of its business copy or evidence of implementation. If the execution baseline or supplied instructions materially differ, preserve this package and follow the revision procedure before affected work.

## Revision control

| Revision | Reason | Affected scope | Acceptance |
| --- | --- | --- | --- |
| 1.0 | Initial upfront compilation from HP-1.1 and pinned guidelines | All ten units and local experiment checks | Accepted under AF-EP-1.0 after compilation validation |

For revisions, save the previous plan/affected unit files under a revision directory, retain unchanged unit revisions, update source/decision/manifest/coverage references, assess previously produced outputs and consumer checks, validate the whole replacement, then record acceptance within delegated authority. Re-run the affected checks; prior evidence keeps its original scope. Permission or business-fact changes require the appropriate owner input, not executor self-authorization. Do not replace this with rolling definition of later units.
