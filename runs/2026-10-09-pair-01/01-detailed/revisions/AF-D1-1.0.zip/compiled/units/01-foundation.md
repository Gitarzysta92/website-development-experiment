# IU-01: Build the project foundation

Revision `1.0`; plan [AF-D1 1.0](../implementation-plan.md); owner: execution agent; contract state: **complete** for the local experiment, 9 October 2026. Execution is initially pending; no output or passing check is claimed.

## Entry instruction

Execute this unit autonomously when its declared inputs are available. Use the shared contracts below, produce the named output, verify it, record the actual result and continue to the next eligible unit in the plan. Do not ask the operator to submit another prompt or approve routine engineering choices.

## Objectives and scope

Objectives: OBJ-07. Create the runnable project and enforce the selected module/runtime boundaries. Do not implement a different stack, deploy, or add unrelated services.

## Source context and applied requirements

Authoritative project contracts: [specification AF-SPEC-1.0](../specification.md), [decisions/policy AF-DEC-1.0 / AF-EP-1.0](../decisions.md), [solution structure AF-STRUCT-1.0](../solution-structure.md), [checks AF-CHECK-1.0](../verification.md), [routes](../routes.json) and [toolchain](../toolchain.json). The supplied [brief](../../inputs/docs/project-brief.md), [sitemap](../../inputs/docs/sitemap.md), [context](../../inputs/content/project-context.md), palette and visual references retain their source roles and limitations.

Guidelines: pinned `f8cb8faf680bde5d194258387543d1e5ebd544dc`. Specialized workflow actions: create-website stages 3–4; add-page-or-feature stages 2–3. Read applicable rule definitions through [rule-coverage.csv](../rule-coverage.csv): rows assigning this unit are owned obligations, with their exact project contract and check; relevant shared-consumer rows remain applicable. Original guideline rule definitions are not replaced by this prompt.

## Structural targets and ownership

Create/change/integrate or verify: E-01, E-07, E-08, E-11, E-12, at the exact locations and runtime boundaries in [the solution map](../solution-structure.md#structural-elements). Preserve declared public APIs and shared ownership. The plan sequences overlapping changes; recheck every affected shared consumer when repairing its owner. This unit does not create an additional application or parallel source of truth.

## Inputs and dependencies

Complete AF-D1 source package; exact toolchain.json; local runtime/package access. No content approval, live account, or deployment access is required.

Required producer outputs: the versioned input and complete compiled package; no earlier implementation unit.

Each local producer is the execution agent. A dependency is available after its output contract/checks pass and its actual version is recorded. Missing environment access blocks only dependent actions. Output contracts are defined upfront; they are not instructions to discover the remaining scope later.

## Compiled actions

1. **IU-01.A1** — Inspect the starting directory, package/source identities and available tools. Record actual baseline and any deviation. Create website/ and the run records from the supplied seeds; never overwrite unrelated existing work.
2. **IU-01.A2** — Create the selected Astro/Node/strict-TypeScript project with exact direct pins from toolchain.json. Install without forced peer bypasses; save package-lock.json, .nvmrc, package-manager identity, environment examples and generated-file exclusions. Missing network/runtime access blocks the installation action, not independent source authoring.
3. **IU-01.A3** — Create the declared public APIs, runtime composition points, separate public/private configuration validation and loopback preview defaults. Add only modules with an implemented responsibility. Establish real dev/build/start/check/test commands and document which later units will supply substantive checks; no false-success scripts.
4. **IU-01.A4** — Configure the first meaningful check/build/start and architecture-boundary mechanism. Keep any temporary development view outside the final content inventory, then remove it once IU-03 provides a representative page. Record commands actually run and hand the working skeleton to IU-02.

## Output and acceptance

**IU-01.O1** — Pinned package manifests/lockfile, actual bootstrap and config, strict typing, module public APIs, working command foundations, ignore rules, blank run records and actual module-map draft. Installation/build facts must be backed by command output.

Planned checks: C-01, C-13, using the exact procedures, test matrix and commands in [verification.md](../verification.md) and [the command contract](../solution-structure.md#command-contract). Execute from `website/` and against the selected local built environment where required. C-01 initial install/check/build/start and C-13 initial import/runtime boundary inspection pass. The complete website is not claimed at this point. Package names/versions match the compiled toolchain, or an accepted replacement package records the change.

The output's consumers and combined checkpoint are defined in the plan. Record output files and implementation fingerprint in `website/docs/execution-record.md`; record actual check outcomes/conditions and artifact links in `website/docs/acceptance-report.md`. Save reports/screenshots under `website/artifacts/`. Do not label planned files or unexecuted checks as complete.

## Failure and revision contract

No unresolved definition gap exists for this local unit. Named future outputs and environment access remain execution prerequisites. Live publication, real receiver/mailbox access, business/asset approval and human translation review remain separately gated by the decisions record.

Repair ordinary defects under this contract and retain failed attempts. For material changes to objectives, structure/public contracts, dependencies or acceptance, follow the plan's complete-package revision procedure, validate shared consumers and record autonomous acceptance within existing authority before affected work. Continue unaffected eligible work. Mark this unit completed only when its output and required checks satisfy the accepted contract.
