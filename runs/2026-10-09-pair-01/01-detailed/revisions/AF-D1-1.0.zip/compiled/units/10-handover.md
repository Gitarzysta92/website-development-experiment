# IU-10: Verify local recovery and deliver the result

Revision `1.0`; plan [AF-D1 1.0](../implementation-plan.md); owner: execution agent; contract state: **complete** for the local experiment, 9 October 2026. Execution is initially pending; no output or passing check is claimed.

## Entry instruction

Execute this unit autonomously when its declared inputs are available. Use the shared contracts below, produce the named output, verify it, record the actual result and continue to the next eligible unit in the plan. Do not ask the operator to submit another prompt or approve routine engineering choices.

## Objectives and scope

Objectives: OBJ-07, OBJ-10. Deliver reproducible local use, editing/extension instructions, local recovery and a truthful release/operations handover. No publication, DNS changes, real email, paid service activation, monitoring schedule or owner approval.

## Source context and applied requirements

Authoritative project contracts: [specification AF-SPEC-1.0](../specification.md), [decisions/policy AF-DEC-1.0 / AF-EP-1.0](../decisions.md), [solution structure AF-STRUCT-1.0](../solution-structure.md), [checks AF-CHECK-1.0](../verification.md), [routes](../routes.json) and [toolchain](../toolchain.json). The supplied [brief](../../inputs/docs/project-brief.md), [sitemap](../../inputs/docs/sitemap.md), [context](../../inputs/content/project-context.md), palette and visual references retain their source roles and limitations.

Guidelines: pinned `f8cb8faf680bde5d194258387543d1e5ebd544dc`. Specialized workflow actions: create-website stages 6–7 (local preparation and handover); execute-implementation-plan stage 6. Read applicable rule definitions through [rule-coverage.csv](../rule-coverage.csv): rows assigning this unit are owned obligations, with their exact project contract and check; relevant shared-consumer rows remain applicable. Original guideline rule definitions are not replaced by this prompt.

## Structural targets and ownership

Create/change/integrate or verify: E-01, E-02, E-12, at the exact locations and runtime boundaries in [the solution map](../solution-structure.md#structural-elements). Preserve declared public APIs and shared ownership. The plan sequences overlapping changes; recheck every affected shared consumer when repairing its owner. This unit does not create an additional application or parallel source of truth.

## Inputs and dependencies

IU-09.O1 verified implementation/evidence, exact lock/config/source fingerprint and recorded launch prerequisites. If IU-09 has a blocked verification action, documentation may be prepared independently but whole-plan completion cannot be claimed.

Required producer outputs: IU-09.O1 at revision 1.0.

Each local producer is the execution agent. A dependency is available after its output contract/checks pass and its actual version is recorded. Missing environment access blocks only dependent actions. Output contracts are defined upfront; they are not instructions to discover the remaining scope later.

## Compiled actions

1. **IU-10.A1** — Complete README and runbook with exact prerequisite/install/check/build/start commands, loopback URL/port, fixture and disabled modes, environment boundaries, generated artifact locations and actual module/public API map.
2. **IU-10.A2** — Document adding a page/content type/feature/adapter, bilingual route registration, shared fact ownership, review invalidation, source/asset provenance, and how to repeat relevant checks without editing generated files.
3. **IU-10.A3** — Demonstrate a representative content edit and restoration to the prior local source/build, retaining failed candidate isolation. Verify no real customer data needs backup in the synthetic mode; document restart cleanup and the limits of local recovery evidence.
4. **IU-10.A4** — List precise live-launch prerequisites and responsible roles: company/technical/Polish/rights reviewers, enquiry/data operator, provider sender/recipient/connection/send authority, hosting/domain operator, complete migration and data policies. Keep them pending; no invented assignments, budget or service SLA.
5. **IU-10.A5** — Evaluate CP-06 and whole-plan conditions, linking evidence and preserving incomplete status if any required check is blocked. Provide the final runnable result, startup instructions, achieved local verification and remaining live limitations without prompting for routine next-unit approval.

## Output and acceptance

**IU-10.O1** — Final README/module map/runbook, demonstrated local restore and command evidence, final acceptance/execution assessment and accurate launch-prerequisite handover.

Planned checks: C-14, C-15, using the exact procedures, test matrix and commands in [verification.md](../verification.md) and [the command contract](../solution-structure.md#command-contract). Execute from `website/` and against the selected local built environment where required. C-14/C-15 and CP-06 pass; all units and required earlier checks satisfy the plan before whole-plan completion is recorded. Implementation, verification, local receipt, real delivery and publication are reported separately.

The output's consumers and combined checkpoint are defined in the plan. Record output files and implementation fingerprint in `website/docs/execution-record.md`; record actual check outcomes/conditions and artifact links in `website/docs/acceptance-report.md`. Save reports/screenshots under `website/artifacts/`. Do not label planned files or unexecuted checks as complete.

## Failure and revision contract

No unresolved definition gap exists for this local unit. Named future outputs and environment access remain execution prerequisites. Live publication, real receiver/mailbox access, business/asset approval and human translation review remain separately gated by the decisions record.

Repair ordinary defects under this contract and retain failed attempts. For material changes to objectives, structure/public contracts, dependencies or acceptance, follow the plan's complete-package revision procedure, validate shared consumers and record autonomous acceptance within existing authority before affected work. Continue unaffected eligible work. Mark this unit completed only when its output and required checks satisfy the accepted contract.
