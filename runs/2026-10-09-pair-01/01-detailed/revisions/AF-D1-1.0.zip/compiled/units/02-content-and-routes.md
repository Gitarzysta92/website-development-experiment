# IU-02: Create bilingual content and route contracts

Revision `1.0`; plan [AF-D1 1.0](../implementation-plan.md); owner: execution agent; contract state: **complete** for the local experiment, 9 October 2026. Execution is initially pending; no output or passing check is claimed.

## Entry instruction

Execute this unit autonomously when its declared inputs are available. Use the shared contracts below, produce the named output, verify it, record the actual result and continue to the next eligible unit in the plan. Do not ask the operator to submit another prompt or approve routine engineering choices.

## Objectives and scope

Objectives: OBJ-01, OBJ-02, OBJ-03, OBJ-06, OBJ-07. Author complete EN/PL local drafts and reusable content/route APIs for all selected identities. Human factual or translation review remains pending.

## Source context and applied requirements

Authoritative project contracts: [specification AF-SPEC-1.0](../specification.md), [decisions/policy AF-DEC-1.0 / AF-EP-1.0](../decisions.md), [solution structure AF-STRUCT-1.0](../solution-structure.md), [checks AF-CHECK-1.0](../verification.md), [routes](../routes.json) and [toolchain](../toolchain.json). The supplied [brief](../../inputs/docs/project-brief.md), [sitemap](../../inputs/docs/sitemap.md), [context](../../inputs/content/project-context.md), palette and visual references retain their source roles and limitations.

Guidelines: pinned `f8cb8faf680bde5d194258387543d1e5ebd544dc`. Specialized workflow actions: create-website stage 4; add-page-or-feature stages 2–4. Read applicable rule definitions through [rule-coverage.csv](../rule-coverage.csv): rows assigning this unit are owned obligations, with their exact project contract and check; relevant shared-consumer rows remain applicable. Original guideline rule definitions are not replaced by this prompt.

## Structural targets and ownership

Create/change/integrate or verify: E-02, E-03, E-06, E-12, at the exact locations and runtime boundaries in [the solution map](../solution-structure.md#structural-elements). Preserve declared public APIs and shared ownership. The plan sequences overlapping changes; recheck every affected shared consumer when repairing its owner. This unit does not create an additional application or parallel source of truth.

## Inputs and dependencies

IU-01.O1 project/schema tooling; HP-1.1 context, brief and complete sitemap; routes.json; decisions D-02/D-03/D-04/D-09. Excluded research PDFs are not inputs.

Required producer outputs: IU-01.O1 at revision 1.0.

Each local producer is the execution agent. A dependency is available after its output contract/checks pass and its actual version is recorded. Missing environment access blocks only dependent actions. Output contracts are defined upfront; they are not instructions to discover the remaining scope later.

## Compiled actions

1. **IU-02.A1** — Define structured page, shared company/project, evidence and media records with stable IDs, locales, source/revision, maturity, privacy and review fields. Validate them using the selected schema tool; create a public projection that cannot serialize private notes or approval records.
2. **IU-02.A2** — Draft all 34 pages from the supplied written context and page briefs. Cover each reader question, meaningful technical detail, claim limitations and onward paths. Centralize reused facts. Preserve differences between proposed sensing, simulation, classical tools and neural research. Omit unsupported company numbers/roles/relationships and describe missing evidence honestly.
3. **IU-02.A3** — Derive the route/navigation API from the selected register: equivalent language paths, hierarchy, breadcrumbs, sibling groups, legacy mapping and allowlisted enquiry context. Do not hand-code competing path strings across templates.
4. **IU-02.A4** — Bind review invalidation and preview/publication eligibility. Define repeatable seeding/import behavior that preserves authored edits and never manufactures approvals. Prepare asset records for the concept visuals IU-03/IU-05 will produce.
5. **IU-02.A5** — Run content/route checks including unique IDs, all locale pairs, reserved/colliding slugs, bad relationships, zero/one/many project fixtures, missing translations, review invalidation and non-destructive re-import. Perform CP-01 and record actual limitations.

## Output and acceptance

**IU-02.O1** — Full 34-page local draft inventory with distinct sections, localized UI/metadata, shared facts and private provenance/review records; validated public views; typed route/CTA API; route/content tests and planned asset records.

Planned checks: C-02, C-03, C-14, using the exact procedures, test matrix and commands in [verification.md](../verification.md) and [the command contract](../solution-structure.md#command-contract). Execute from `website/` and against the selected local built environment where required. C-02 content inventory and factual limits, C-03 route/collection/translation robustness and applicable C-14 editing/invalidation checks pass. All required subjects have substantive drafts; schema success alone does not satisfy editorial review.

The output's consumers and combined checkpoint are defined in the plan. Record output files and implementation fingerprint in `website/docs/execution-record.md`; record actual check outcomes/conditions and artifact links in `website/docs/acceptance-report.md`. Save reports/screenshots under `website/artifacts/`. Do not label planned files or unexecuted checks as complete.

## Failure and revision contract

No unresolved definition gap exists for this local unit. Named future outputs and environment access remain execution prerequisites. Live publication, real receiver/mailbox access, business/asset approval and human translation review remain separately gated by the decisions record.

Repair ordinary defects under this contract and retain failed attempts. For material changes to objectives, structure/public contracts, dependencies or acceptance, follow the plan's complete-package revision procedure, validate shared consumers and record autonomous acceptance within existing authority before affected work. Continue unaffected eligible work. Mark this unit completed only when its output and required checks satisfy the accepted contract.
