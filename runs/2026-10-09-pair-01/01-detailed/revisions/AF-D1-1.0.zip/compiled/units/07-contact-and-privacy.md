# IU-07: Complete the contact journey and local privacy page

Revision `1.0`; plan [AF-D1 1.0](../implementation-plan.md); owner: execution agent; contract state: **complete** for the local experiment, 9 October 2026. Execution is initially pending; no output or passing check is claimed.

## Entry instruction

Execute this unit autonomously when its declared inputs are available. Use the shared contracts below, produce the named output, verify it, record the actual result and continue to the next eligible unit in the plan. Do not ask the operator to submit another prompt or approve routine engineering choices.

## Objectives and scope

Objectives: OBJ-01, OBJ-02, OBJ-03, OBJ-04, OBJ-05, OBJ-08. Finish Contact and Privacy in EN/PL and connect contextual calls to action across the website. Preserve the selected form plus public email.

## Source context and applied requirements

Authoritative project contracts: [specification AF-SPEC-1.0](../specification.md), [decisions/policy AF-DEC-1.0 / AF-EP-1.0](../decisions.md), [solution structure AF-STRUCT-1.0](../solution-structure.md), [checks AF-CHECK-1.0](../verification.md), [routes](../routes.json) and [toolchain](../toolchain.json). The supplied [brief](../../inputs/docs/project-brief.md), [sitemap](../../inputs/docs/sitemap.md), [context](../../inputs/content/project-context.md), palette and visual references retain their source roles and limitations.

Guidelines: pinned `f8cb8faf680bde5d194258387543d1e5ebd544dc`. Specialized workflow actions: create-website stages 3–4; add-page-or-feature stages 3–4. Read applicable rule definitions through [rule-coverage.csv](../rule-coverage.csv): rows assigning this unit are owned obligations, with their exact project contract and check; relevant shared-consumer rows remain applicable. Original guideline rule definitions are not replaced by this prompt.

## Structural targets and ownership

Create/change/integrate or verify: E-02, E-04, E-05, E-06, E-10, E-12, at the exact locations and runtime boundaries in [the solution map](../solution-structure.md#structural-elements). Preserve declared public APIs and shared ownership. The plan sequences overlapping changes; recheck every affected shared consumer when repairing its owner. This unit does not create an additional application or parallel source of truth.

## Inputs and dependencies

IU-02.O1 copy/route/locale data; IU-03.O1 controls/layout; IU-06.O1 endpoint/receiver/result contracts. IU-04/IU-05 page groups provide the combined journey for CP-03.

Required producer outputs: IU-02.O1 at revision 1.0, IU-03.O1 at revision 1.0, IU-06.O1 at revision 1.0.

Each local producer is the execution agent. A dependency is available after its output contract/checks pass and its actual version is recorded. Missing environment access blocks only dependent actions. Output contracts are defined upfront; they are not instructions to discover the remaining scope later.

## Compiled actions

1. **IU-07.A1** — Implement form markup/controller with visible labels, hints, field/error association, status announcement, editable intent/project and safe query preselection. Keep values and submission ID page-local; no persistent browser storage or personal URLs.
2. **IU-07.A2** — Integrate all ENQ-1.0 outcomes, progress/duplicate prevention, cancellation/late-result protection, input preservation, uncertain manual retry behavior and always-visible email alternative. Fixture acceptance visibly states local test only; no-JS browsing retains the email path.
3. **IU-07.A3** — Write bilingual Privacy text matching actual synthetic/loopback behavior, memory expiration/restart, absence of tracking and email-client fallback. Record missing production controller/provider/operator arrangements privately; do not invent legal facts or finalized live privacy assurances.
4. **IU-07.A4** — Exercise the investor, partner and demo journeys from the completed page groups. Verify preselection remains editable, failures retain input, receipt is independently observable, UI states are translated, and reduced-motion/keyboard/narrow/short layouts hold.
5. **IU-07.A5** — Perform CP-03 against all 34 pages, record true synthetic receipt and error-state evidence, and correct shared consumers without adding a separate thank-you route or unsolicited account/CRM features.

## Output and acceptance

**IU-07.O1** — Four Contact/Privacy routes, integrated form/controller, localized validation/status states, context links and complete local enquiry journeys with actual synthetic evidence.

Planned checks: C-02, C-04, C-05, C-06, C-08, C-09, C-11, using the exact procedures, test matrix and commands in [verification.md](../verification.md) and [the command contract](../solution-structure.md#command-contract). Execute from `website/` and against the selected local built environment where required. Applicable C-02/C-04/C-05/C-06/C-08/C-09/C-11 checks and CP-03 pass. Form failure never loses entered text, test mode never claims a real enquiry, and privacy text describes observed behavior.

The output's consumers and combined checkpoint are defined in the plan. Record output files and implementation fingerprint in `website/docs/execution-record.md`; record actual check outcomes/conditions and artifact links in `website/docs/acceptance-report.md`. Save reports/screenshots under `website/artifacts/`. Do not label planned files or unexecuted checks as complete.

## Failure and revision contract

No unresolved definition gap exists for this local unit. Named future outputs and environment access remain execution prerequisites. Live publication, real receiver/mailbox access, business/asset approval and human translation review remain separately gated by the decisions record.

Repair ordinary defects under this contract and retain failed attempts. For material changes to objectives, structure/public contracts, dependencies or acceptance, follow the plan's complete-package revision procedure, validate shared consumers and record autonomous acceptance within existing authority before affected work. Continue unaffected eligible work. Mark this unit completed only when its output and required checks satisfy the accepted contract.
