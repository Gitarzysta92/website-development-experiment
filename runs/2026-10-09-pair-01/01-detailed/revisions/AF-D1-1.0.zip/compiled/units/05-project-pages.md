# IU-05: Compose the two substantive project branches

Revision `1.0`; plan [AF-D1 1.0](../implementation-plan.md); owner: execution agent; contract state: **complete** for the local experiment, 9 October 2026. Execution is initially pending; no output or passing check is claimed.

## Entry instruction

Execute this unit autonomously when its declared inputs are available. Use the shared contracts below, produce the named output, verify it, record the actual result and continue to the next eligible unit in the plan. Do not ask the operator to submit another prompt or approve routine engineering choices.

## Objectives and scope

Objectives: OBJ-01, OBJ-02, OBJ-03, OBJ-04. Finish ArtiSense overview plus 3 children, and AIFIELD overview plus 4 children, in both languages: nine identities / eighteen routes.

## Source context and applied requirements

Authoritative project contracts: [specification AF-SPEC-1.0](../specification.md), [decisions/policy AF-DEC-1.0 / AF-EP-1.0](../decisions.md), [solution structure AF-STRUCT-1.0](../solution-structure.md), [checks AF-CHECK-1.0](../verification.md), [routes](../routes.json) and [toolchain](../toolchain.json). The supplied [brief](../../inputs/docs/project-brief.md), [sitemap](../../inputs/docs/sitemap.md), [context](../../inputs/content/project-context.md), palette and visual references retain their source roles and limitations.

Guidelines: pinned `f8cb8faf680bde5d194258387543d1e5ebd544dc`. Specialized workflow actions: create-website stage 4; add-page-or-feature stages 2–4. Read applicable rule definitions through [rule-coverage.csv](../rule-coverage.csv): rows assigning this unit are owned obligations, with their exact project contract and check; relevant shared-consumer rows remain applicable. Original guideline rule definitions are not replaced by this prompt.

## Structural targets and ownership

Create/change/integrate or verify: E-02, E-03, E-04, E-05, E-06, E-12, at the exact locations and runtime boundaries in [the solution map](../solution-structure.md#structural-elements). Preserve declared public APIs and shared ownership. The plan sequences overlapping changes; recheck every affected shared consumer when repairing its owner. This unit does not create an additional application or parallel source of truth.

## Inputs and dependencies

IU-02.O1 project/evidence drafts and IU-03.O1 visual/shell patterns. IU-04 may have refined shared components; inspect current consumers before changes.

Required producer outputs: IU-02.O1 at revision 1.0, IU-03.O1 at revision 1.0.

Each local producer is the execution agent. A dependency is available after its output contract/checks pass and its actual version is recorded. Missing environment access blocks only dependent actions. Output contracts are defined upfront; they are not instructions to discover the remaining scope later.

## Compiled actions

1. **IU-05.A1** — Implement all supplied reader questions with clear introductions and distinct content ownership. ArtiSense covers technology, intended applications and research/validation; AIFIELD covers design/simulation, agent assistance, neural field research and examples/validation.
2. **IU-05.A2** — Create explanatory diagrams for the proposed sensing chain, design/simulation stages and AI/human boundaries using original accessible vectors. Label conceptual or research status. Without approved screenshots or numeric benchmarks, use accurate explanatory evidence/limitations layouts rather than fake dashboards or data plots.
3. **IU-05.A3** — Preserve the source distinctions and dated evidence, linking the shared glucose example from the design perspective to the separate sensing validation needs. Neural field limitations remain attached; no clinical, fabricated-device or speed claims are inferred.
4. **IU-05.A4** — Implement project-local navigation, breadcrumbs, useful related evidence, context CTAs and direct-arrival orientation. Keep the four old Polish ArtiSense anchor targets on its overview with relevant summaries and links.
5. **IU-05.A5** — Verify overview/children in EN/PL, actual diagram alternatives, readable long prose/tables, sidebar fit, legacy anchor positions and narrow/short layouts. Update private asset provenance and shared-content references without claiming owner approval.

## Output and acceptance

**IU-05.O1** — Eighteen substantive project routes, original labeled diagrams with EN/PL alternatives, project navigation, evidence/limit sections and legacy overview anchors.

Planned checks: C-02, C-03, C-04, C-05, C-06, using the exact procedures, test matrix and commands in [verification.md](../verification.md) and [the command contract](../solution-structure.md#command-contract). Execute from `website/` and against the selected local built environment where required. C-02/C-03/C-04/C-05/C-06 pass for this branch. Every technical child is substantive and distinct; real evidence and concept explanation remain distinguishable.

The output's consumers and combined checkpoint are defined in the plan. Record output files and implementation fingerprint in `website/docs/execution-record.md`; record actual check outcomes/conditions and artifact links in `website/docs/acceptance-report.md`. Save reports/screenshots under `website/artifacts/`. Do not label planned files or unexecuted checks as complete.

## Failure and revision contract

No unresolved definition gap exists for this local unit. Named future outputs and environment access remain execution prerequisites. Live publication, real receiver/mailbox access, business/asset approval and human translation review remain separately gated by the decisions record.

Repair ordinary defects under this contract and retain failed attempts. For material changes to objectives, structure/public contracts, dependencies or acceptance, follow the plan's complete-package revision procedure, validate shared consumers and record autonomous acceptance within existing authority before affected work. Continue unaffected eligible work. Mark this unit completed only when its output and required checks satisfy the accepted contract.
