# IU-03: Establish the design system and shared shell

Revision `1.0`; plan [AF-D1 1.0](../implementation-plan.md); owner: execution agent; contract state: **complete** for the local experiment, 9 October 2026. Execution is initially pending; no output or passing check is claimed.

## Entry instruction

Execute this unit autonomously when its declared inputs are available. Use the shared contracts below, produce the named output, verify it, record the actual result and continue to the next eligible unit in the plan. Do not ask the operator to submit another prompt or approve routine engineering choices.

## Objectives and scope

Objectives: OBJ-02, OBJ-03, OBJ-04. Build reusable tokens, components, navigation and one representative bilingual page. Refine bounded composition/spacing details autonomously without replacing the selected palette or whole architecture.

## Source context and applied requirements

Authoritative project contracts: [specification AF-SPEC-1.0](../specification.md), [decisions/policy AF-DEC-1.0 / AF-EP-1.0](../decisions.md), [solution structure AF-STRUCT-1.0](../solution-structure.md), [checks AF-CHECK-1.0](../verification.md), [routes](../routes.json) and [toolchain](../toolchain.json). The supplied [brief](../../inputs/docs/project-brief.md), [sitemap](../../inputs/docs/sitemap.md), [context](../../inputs/content/project-context.md), palette and visual references retain their source roles and limitations.

Guidelines: pinned `f8cb8faf680bde5d194258387543d1e5ebd544dc`. Specialized workflow actions: create-website stage 3; add-page-or-feature stages 2–4. Read applicable rule definitions through [rule-coverage.csv](../rule-coverage.csv): rows assigning this unit are owned obligations, with their exact project contract and check; relevant shared-consumer rows remain applicable. Original guideline rule definitions are not replaced by this prompt.

## Structural targets and ownership

Create/change/integrate or verify: E-04, E-05, E-06, E-12, at the exact locations and runtime boundaries in [the solution map](../solution-structure.md#structural-elements). Preserve declared public APIs and shared ownership. The plan sequences overlapping changes; recheck every affected shared consumer when repairing its owner. This unit does not create an additional application or parallel source of truth.

## Inputs and dependencies

IU-01.O1 runtime; IU-02.O1 draft views/navigation; original palette/CSS and all supplied design-reference images. New visual work is bounded by AF-SPEC-1.0.

Required producer outputs: IU-01.O1 at revision 1.0, IU-02.O1 at revision 1.0.

Each local producer is the execution agent. A dependency is available after its output contract/checks pass and its actual version is recorded. Missing environment access blocks only dependent actions. Output contracts are defined upfront; they are not instructions to discover the remaining scope later.

## Compiled actions

1. **IU-03.A1** — Inspect the supplied board and individual reference captures. Implement the specification typography, widths, spacing, state and motion tokens, retaining supplied color values. Create the local text wordmark and original concept-only visual language, with provenance/alternatives.
2. **IU-03.A2** — Build generic UI components with explicit props/events and scoped styles: links/buttons, project card, evidence/status callout, figure/caption, data table and form controls. Cover actual default/hover/focus/disabled/error states in a private local component reference, not an unrelated public page.
3. **IU-03.A3** — Implement shared layout and application-aware header/footer/breadcrumb/project navigation consuming the route API. Use accessible disclosure behavior, one shell-owned menu state, current-page semantics, stable geometry, responsive wrapping, anchor offsets and short-screen sidebar fallback.
4. **IU-03.A4** — Render a representative ArtiSense technical page in EN/PL using real draft content plus its project/global context. Verify the vertical route→content view→shell/components path. Save actual narrow/wide screenshots and compare hierarchy/composition against the references.
5. **IU-03.A5** — Run CP-02 keyboard/touch/responsive/long-Polish/state checks. Fix shared primitives before consumers reuse them. Record any bounded breakpoint adjustment centrally; no routine operator design approval.

## Output and acceptance

**IU-03.O1** — Semantic design tokens, reusable UI/state reference, shared shell/chrome, original concept assets and a rendered representative EN/PL technical journey with screenshots and checks.

Planned checks: C-03, C-04, C-05, C-06, using the exact procedures, test matrix and commands in [verification.md](../verification.md) and [the command contract](../solution-structure.md#command-contract). Execute from `website/` and against the selected local built environment where required. C-03/C-04/C-05/C-06 representative checks pass. Actual layouts use the supplied palette, readable technical copy and meaningful visuals; navigation works without hover and at short/narrow sizes.

The output's consumers and combined checkpoint are defined in the plan. Record output files and implementation fingerprint in `website/docs/execution-record.md`; record actual check outcomes/conditions and artifact links in `website/docs/acceptance-report.md`. Save reports/screenshots under `website/artifacts/`. Do not label planned files or unexecuted checks as complete.

## Failure and revision contract

No unresolved definition gap exists for this local unit. Named future outputs and environment access remain execution prerequisites. Live publication, real receiver/mailbox access, business/asset approval and human translation review remain separately gated by the decisions record.

Repair ordinary defects under this contract and retain failed attempts. For material changes to objectives, structure/public contracts, dependencies or acceptance, follow the plan's complete-package revision procedure, validate shared consumers and record autonomous acceptance within existing authority before affected work. Continue unaffected eligible work. Mark this unit completed only when its output and required checks satisfy the accepted contract.
