# IU-09: Verify and repair the complete local website

Revision `1.0`; plan [AF-D1 1.0](../implementation-plan.md); owner: execution agent; contract state: **complete** for the local experiment, 9 October 2026. Execution is initially pending; no output or passing check is claimed.

## Entry instruction

Execute this unit autonomously when its declared inputs are available. Use the shared contracts below, produce the named output, verify it, record the actual result and continue to the next eligible unit in the plan. Do not ask the operator to submit another prompt or approve routine engineering choices.

## Objectives and scope

Objectives: OBJ-09. Run the required integrated quality checks, inspect actual rendered content/design, repair defects under existing contracts and record honest coverage. No production claims.

## Source context and applied requirements

Authoritative project contracts: [specification AF-SPEC-1.0](../specification.md), [decisions/policy AF-DEC-1.0 / AF-EP-1.0](../decisions.md), [solution structure AF-STRUCT-1.0](../solution-structure.md), [checks AF-CHECK-1.0](../verification.md), [routes](../routes.json) and [toolchain](../toolchain.json). The supplied [brief](../../inputs/docs/project-brief.md), [sitemap](../../inputs/docs/sitemap.md), [context](../../inputs/content/project-context.md), palette and visual references retain their source roles and limitations.

Guidelines: pinned `f8cb8faf680bde5d194258387543d1e5ebd544dc`. Specialized workflow actions: create-website stage 5; add-page-or-feature stage 4; execute-implementation-plan stages 4–5. Read applicable rule definitions through [rule-coverage.csv](../rule-coverage.csv): rows assigning this unit are owned obligations, with their exact project contract and check; relevant shared-consumer rows remain applicable. Original guideline rule definitions are not replaced by this prompt.

## Structural targets and ownership

Create/change/integrate or verify: E-01, E-02, E-03, E-04, E-05, E-06, E-07, E-08, E-09, E-10, E-11, E-12, at the exact locations and runtime boundaries in [the solution map](../solution-structure.md#structural-elements). Preserve declared public APIs and shared ownership. The plan sequences overlapping changes; recheck every affected shared consumer when repairing its owner. This unit does not create an additional application or parallel source of truth.

## Inputs and dependencies

IU-08.O1 integrated artifact and all producer outputs; AF-CHECK-1.0, rule coverage, unit evidence and available browsers. Network/browser-install permission is an environment prerequisite, not a reason to invent results.

Required producer outputs: IU-08.O1 at revision 1.0.

Each local producer is the execution agent. A dependency is available after its output contract/checks pass and its actual version is recorded. Missing environment access blocks only dependent actions. Output contracts are defined upfront; they are not instructions to discover the remaining scope later.

## Compiled actions

1. **IU-09.A1** — Record the implementation fingerprint and actual runtime/browser/OS. Run a reproducible npm ci build and all applicable content/type/domain/adapter/boundary checks. Ensure no test command is a stub and no fixture silently substitutes for a required real boundary.
2. **IU-09.A2** — Exercise the complete verification matrix: all route/link/metadata smoke checks, critical EN/PL journeys and browsers, responsive states, keyboard/touch/focus, zoom, motion, errors/outages/duplicates, preview isolation and private-output boundaries. Manually inspect the actual screenshots and substantive copy.
3. **IU-09.A3** — Measure defined transfer budgets and three cold mobile Lighthouse runs for EN Home and the longest PL technical page. Save individual and median results with conditions; inspect warm/failure behavior separately. Do not weaken the budgets to hide an implementation problem.
4. **IU-09.A4** — Repair findings at their owning component/content/feature boundary, retaining failed evidence and rerunning the affected shared consumers. If a contract truly must change, use the complete-package revision/acceptance process before affected work.
5. **IU-09.A5** — Account for every applicable rule/objective/check and combined checkpoint with actual evidence or an explicit unresolved gap. Perform CP-05 only when required local checks pass. If an environment blocker remains, preserve incomplete verification status and continue independent handover preparation.

## Output and acceptance

**IU-09.O1** — Repaired website, actual executed check reports, inspected screenshots, performance measurements, objective/rule evidence and explicit remaining gaps, all bound to the final local implementation fingerprint.

Planned checks: C-01, C-02, C-03, C-04, C-05, C-06, C-07, C-08, C-09, C-10, C-11, C-12, C-13, C-14, using the exact procedures, test matrix and commands in [verification.md](../verification.md) and [the command contract](../solution-structure.md#command-contract). Execute from `website/` and against the selected local built environment where required. All required C-01 through C-14 conditions and CP-05 pass for verified local completion. Failed or unavailable checks keep their actual outcomes; isolated tests remain distinct from real integration and deployed evidence.

The output's consumers and combined checkpoint are defined in the plan. Record output files and implementation fingerprint in `website/docs/execution-record.md`; record actual check outcomes/conditions and artifact links in `website/docs/acceptance-report.md`. Save reports/screenshots under `website/artifacts/`. Do not label planned files or unexecuted checks as complete.

## Failure and revision contract

No unresolved definition gap exists for this local unit. Named future outputs and environment access remain execution prerequisites. Live publication, real receiver/mailbox access, business/asset approval and human translation review remain separately gated by the decisions record.

Repair ordinary defects under this contract and retain failed attempts. For material changes to objectives, structure/public contracts, dependencies or acceptance, follow the plan's complete-package revision procedure, validate shared consumers and record autonomous acceptance within existing authority before affected work. Continue unaffected eligible work. Mark this unit completed only when its output and required checks satisfy the accepted contract.
