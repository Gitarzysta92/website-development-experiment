# IU-08: Integrate discovery, migration and exposure boundaries

Revision `1.0`; plan [AF-D1 1.0](../implementation-plan.md); owner: execution agent; contract state: **complete** for the local experiment, 9 October 2026. Execution is initially pending; no output or passing check is claimed.

## Entry instruction

Execute this unit autonomously when its declared inputs are available. Use the shared contracts below, produce the named output, verify it, record the actual result and continue to the next eligible unit in the plan. Do not ask the operator to submit another prompt or approve routine engineering choices.

## Objectives and scope

Objectives: OBJ-02, OBJ-03, OBJ-06, OBJ-07, OBJ-08. Integrate the complete local website and production-export contract; implement known redirects, metadata, headers and leak checks. Do not deploy or approve drafts.

## Source context and applied requirements

Authoritative project contracts: [specification AF-SPEC-1.0](../specification.md), [decisions/policy AF-DEC-1.0 / AF-EP-1.0](../decisions.md), [solution structure AF-STRUCT-1.0](../solution-structure.md), [checks AF-CHECK-1.0](../verification.md), [routes](../routes.json) and [toolchain](../toolchain.json). The supplied [brief](../../inputs/docs/project-brief.md), [sitemap](../../inputs/docs/sitemap.md), [context](../../inputs/content/project-context.md), palette and visual references retain their source roles and limitations.

Guidelines: pinned `f8cb8faf680bde5d194258387543d1e5ebd544dc`. Specialized workflow actions: create-website stages 4–6 (release preparation only); add-page-or-feature stages 3–4. Read applicable rule definitions through [rule-coverage.csv](../rule-coverage.csv): rows assigning this unit are owned obligations, with their exact project contract and check; relevant shared-consumer rows remain applicable. Original guideline rule definitions are not replaced by this prompt.

## Structural targets and ownership

Create/change/integrate or verify: E-01, E-02, E-03, E-09, E-11, E-12, at the exact locations and runtime boundaries in [the solution map](../solution-structure.md#structural-elements). Preserve declared public APIs and shared ownership. The plan sequences overlapping changes; recheck every affected shared consumer when repairing its owner. This unit does not create an additional application or parallel source of truth.

## Inputs and dependencies

IU-04.O1 company pages, IU-05.O1 project pages and IU-07.O1 contact/privacy; all inherited schema/navigation/receiver outputs; configured loopback origin.

Required producer outputs: IU-04.O1 at revision 1.0, IU-05.O1 at revision 1.0, IU-07.O1 at revision 1.0.

Each local producer is the execution agent. A dependency is available after its output contract/checks pass and its actual version is recorded. Missing environment access blocks only dependent actions. Output contracts are defined upfront; they are not instructions to discover the remaining scope later.

## Compiled actions

1. **IU-08.A1** — Generate all localized metadata, canonical/alternate/share values and technical routes from the authoritative public projections and route API. Published-only sitemap behavior is checked with isolated synthetic approved fixtures; current real drafts remain preview-only.
2. **IU-08.A2** — Implement input sitemap path redirects and Polish fragment arrivals with correct statuses; unknown paths get true localized 404 recovery. Check direct entry, trailing-slash/case handling and absence of redirect chains; document incomplete historic inventory.
3. **IU-08.A3** — Enforce separate preview/published build profiles and fail closed for missing approvals/configuration. Keep failed candidate builds from replacing the usable prior artifact: build/validate into a separate candidate directory before selecting it as the local artifact. No service activation is part of this build step.
4. **IU-08.A4** — Apply actual headers/cache behavior to built HTML, static resources and API; verify loopback protection and fixture mode restriction. Inspect served output/client bundles for secrets, raw private content records, source inputs, guidelines, test fixtures and local path leaks.
5. **IU-08.A5** — Implement meaningful link/asset/metadata/gate checks; exercise draft edits/review invalidation and rejected incomplete public builds. Run CP-04 over the integrated built server and repair discrepancies.

## Output and acceptance

**IU-08.O1** — Coherent 34-route local build, discovery/publication serializers and gates, safe technical responses, legacy redirects, isolated approved fixtures and automated link/exposure checks.

Planned checks: C-03, C-10, C-11, C-13, C-14, using the exact procedures, test matrix and commands in [verification.md](../verification.md) and [the command contract](../solution-structure.md#command-contract). Execute from `website/` and against the selected local built environment where required. C-03/C-10/C-11/C-13/C-14 and CP-04 pass. No actual draft approval or public release occurs. Effective responses match the contracts, not merely the source configuration.

The output's consumers and combined checkpoint are defined in the plan. Record output files and implementation fingerprint in `website/docs/execution-record.md`; record actual check outcomes/conditions and artifact links in `website/docs/acceptance-report.md`. Save reports/screenshots under `website/artifacts/`. Do not label planned files or unexecuted checks as complete.

## Failure and revision contract

No unresolved definition gap exists for this local unit. Named future outputs and environment access remain execution prerequisites. Live publication, real receiver/mailbox access, business/asset approval and human translation review remain separately gated by the decisions record.

Repair ordinary defects under this contract and retain failed attempts. For material changes to objectives, structure/public contracts, dependencies or acceptance, follow the plan's complete-package revision procedure, validate shared consumers and record autonomous acceptance within existing authority before affected work. Continue unaffected eligible work. Mark this unit completed only when its output and required checks satisfy the accepted contract.
