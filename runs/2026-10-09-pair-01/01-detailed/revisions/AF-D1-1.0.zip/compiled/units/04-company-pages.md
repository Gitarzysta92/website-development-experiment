# IU-04: Compose company and index pages

Revision `1.0`; plan [AF-D1 1.0](../implementation-plan.md); owner: execution agent; contract state: **complete** for the local experiment, 9 October 2026. Execution is initially pending; no output or passing check is claimed.

## Entry instruction

Execute this unit autonomously when its declared inputs are available. Use the shared contracts below, produce the named output, verify it, record the actual result and continue to the next eligible unit in the plan. Do not ask the operator to submit another prompt or approve routine engineering choices.

## Objectives and scope

Objectives: OBJ-01, OBJ-02, OBJ-03, OBJ-04. Finish Home, Projects, Investors, Our Approach, About and Partnerships, in EN and PL: six identities / twelve routes.

## Source context and applied requirements

Authoritative project contracts: [specification AF-SPEC-1.0](../specification.md), [decisions/policy AF-DEC-1.0 / AF-EP-1.0](../decisions.md), [solution structure AF-STRUCT-1.0](../solution-structure.md), [checks AF-CHECK-1.0](../verification.md), [routes](../routes.json) and [toolchain](../toolchain.json). The supplied [brief](../../inputs/docs/project-brief.md), [sitemap](../../inputs/docs/sitemap.md), [context](../../inputs/content/project-context.md), palette and visual references retain their source roles and limitations.

Guidelines: pinned `f8cb8faf680bde5d194258387543d1e5ebd544dc`. Specialized workflow actions: create-website stage 4; add-page-or-feature stages 2–4. Read applicable rule definitions through [rule-coverage.csv](../rule-coverage.csv): rows assigning this unit are owned obligations, with their exact project contract and check; relevant shared-consumer rows remain applicable. Original guideline rule definitions are not replaced by this prompt.

## Structural targets and ownership

Create/change/integrate or verify: E-02, E-03, E-04, E-05, E-06, at the exact locations and runtime boundaries in [the solution map](../solution-structure.md#structural-elements). Preserve declared public APIs and shared ownership. The plan sequences overlapping changes; recheck every affected shared consumer when repairing its owner. This unit does not create an additional application or parallel source of truth.

## Inputs and dependencies

IU-02.O1 content/route API and IU-03.O1 shell/design conventions. Shared visual changes must preserve existing representative consumers.

Required producer outputs: IU-02.O1 at revision 1.0, IU-03.O1 at revision 1.0.

Each local producer is the execution agent. A dependency is available after its output contract/checks pass and its actual version is recorded. Missing environment access blocks only dependent actions. Output contracts are defined upfront; they are not instructions to discover the remaining scope later.

## Compiled actions

1. **IU-04.A1** — Compose these six page types from their distinct sitemap purpose and IU-02 copy. Home makes the company investment thesis understandable; Projects compares the two subjects; Investors keeps the opportunity company-level and enquiry-led.
2. **IU-04.A2** — Give Our Approach a distinct explanation of evidence and proposed validation sequence, explicitly qualified where unconfirmed. About explains company/project focus without invented biographies. Partnerships distinguishes possible collaboration topics from confirmed relationships.
3. **IU-04.A3** — Use varied editorial composition, substantial concept visuals, precise maturity labels and contextual links. Do not copy external screenshots, fabricate traction, or fill absent logos/portraits/financial data with invented material.
4. **IU-04.A4** — Connect investor/partner actions to the typed contact helper and keep all purposes reachable through shared navigation. Check all EN/PL routes and primary paths; test long labels, narrow layout, missing optional assets and shared component consumers.

## Output and acceptance

**IU-04.O1** — Twelve complete company/index routes, their asset/copy refinements and contextual navigation, using shared view/visual contracts.

Planned checks: C-02, C-03, C-04, C-06, using the exact procedures, test matrix and commands in [verification.md](../verification.md) and [the command contract](../solution-structure.md#command-contract). Execute from `website/` and against the selected local built environment where required. C-02/C-03/C-04/C-06 checks for these routes pass. Each page has a distinct visitor purpose and useful content; all links and long Polish layouts work.

The output's consumers and combined checkpoint are defined in the plan. Record output files and implementation fingerprint in `website/docs/execution-record.md`; record actual check outcomes/conditions and artifact links in `website/docs/acceptance-report.md`. Save reports/screenshots under `website/artifacts/`. Do not label planned files or unexecuted checks as complete.

## Failure and revision contract

No unresolved definition gap exists for this local unit. Named future outputs and environment access remain execution prerequisites. Live publication, real receiver/mailbox access, business/asset approval and human translation review remain separately gated by the decisions record.

Repair ordinary defects under this contract and retain failed attempts. For material changes to objectives, structure/public contracts, dependencies or acceptance, follow the plan's complete-package revision procedure, validate shared consumers and record autonomous acceptance within existing authority before affected work. Continue unaffected eligible work. Mark this unit completed only when its output and required checks satisfy the accepted contract.
