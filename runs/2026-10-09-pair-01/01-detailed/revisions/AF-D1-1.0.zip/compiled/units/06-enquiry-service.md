# IU-06: Implement the enquiry boundary and receiver adapters

Revision `1.0`; plan [AF-D1 1.0](../implementation-plan.md); owner: execution agent; contract state: **complete** for the local experiment, 9 October 2026. Execution is initially pending; no output or passing check is claimed.

## Entry instruction

Execute this unit autonomously when its declared inputs are available. Use the shared contracts below, produce the named output, verify it, record the actual result and continue to the next eligible unit in the plan. Do not ask the operator to submit another prompt or approve routine engineering choices.

## Objectives and scope

Objectives: OBJ-05, OBJ-07, OBJ-08. Implement the pure request/result contract, use case, trusted endpoint, local synthetic receiver, disabled receiver and concrete Resend HTTP adapter. No real outgoing message or account provisioning.

## Source context and applied requirements

Authoritative project contracts: [specification AF-SPEC-1.0](../specification.md), [decisions/policy AF-DEC-1.0 / AF-EP-1.0](../decisions.md), [solution structure AF-STRUCT-1.0](../solution-structure.md), [checks AF-CHECK-1.0](../verification.md), [routes](../routes.json) and [toolchain](../toolchain.json). The supplied [brief](../../inputs/docs/project-brief.md), [sitemap](../../inputs/docs/sitemap.md), [context](../../inputs/content/project-context.md), palette and visual references retain their source roles and limitations.

Guidelines: pinned `f8cb8faf680bde5d194258387543d1e5ebd544dc`. Specialized workflow actions: create-website stage 4; add-page-or-feature stages 2–4. Read applicable rule definitions through [rule-coverage.csv](../rule-coverage.csv): rows assigning this unit are owned obligations, with their exact project contract and check; relevant shared-consumer rows remain applicable. Original guideline rule definitions are not replaced by this prompt.

## Structural targets and ownership

Create/change/integrate or verify: E-07, E-08, E-11, E-12, at the exact locations and runtime boundaries in [the solution map](../solution-structure.md#structural-elements). Preserve declared public APIs and shared ownership. The plan sequences overlapping changes; recheck every affected shared consumer when repairing its owner. This unit does not create an additional application or parallel source of truth.

## Inputs and dependencies

IU-01.O1 private config/composition/tooling and IU-02.O1 locale/intent contracts. ENQ-1.0 is fully defined in the specification. Live credentials and send authority are not supplied or needed for isolated/local checks.

Required producer outputs: IU-01.O1 at revision 1.0, IU-02.O1 at revision 1.0.

Each local producer is the execution agent. A dependency is available after its output contract/checks pass and its actual version is recorded. Missing environment access blocks only dependent actions. Output contracts are defined upfront; they are not instructions to discover the remaining scope later.

## Compiled actions

1. **IU-06.A1** — Implement the ENQ-1.0 schema and explicit result union, keeping domain rules framework-independent. Create the receiver port and use case with injected receiver/clock/transport at the declared composition boundary.
2. **IU-06.A2** — Implement POST method/JSON/schema/origin/actual body size checks, bounded direct-peer limiter, fixed destination control, safe errors, timeouts and payload-free diagnostics. Keep runtime secrets server-only and browser state out of server global request objects.
3. **IU-06.A3** — Implement an inspectable process-local synthetic fixture receiver with atomic idempotent acceptance, bounded retention and deterministic error injection only in test composition. Implement the disabled adapter with honest unavailable behavior.
4. **IU-06.A4** — Implement Resend request/response mapping and idempotency from the pinned protocol sources: fixed recipient, validated reply address, plain text, preserved payload/key, confirmed ID only, bounded waits and uncertain outcomes. Keep live activation behind all policy/configuration prerequisites and never substitute fixture success.
5. **IU-06.A5** — Run controlled domain/endpoint/adapter tests across the full C-07/C-08 matrix, including concurrent duplicates, changed payload, malformed success, uncertain retry cutoff, local receipt inspection and fixture/public-host rejection. Verify the adapter can change without page changes; record isolated/local/live evidence separately.

## Output and acceptance

**IU-06.O1** — ENQ-1.0 public schemas/use case/port, endpoint and one server composition root, fixture/disabled/Resend implementations, deterministic meaningful tests, safe env examples and data-lifetime documentation.

Planned checks: C-07, C-08, C-11, C-13, using the exact procedures, test matrix and commands in [verification.md](../verification.md) and [the command contract](../solution-structure.md#command-contract). Execute from `website/` and against the selected local built environment where required. C-07/C-08/C-11/C-13 relevant checks pass. A synthetic submission is independently found in the fixture receiver exactly once; no real provider send occurs. Provider protocol tests do not establish mailbox delivery.

The output's consumers and combined checkpoint are defined in the plan. Record output files and implementation fingerprint in `website/docs/execution-record.md`; record actual check outcomes/conditions and artifact links in `website/docs/acceptance-report.md`. Save reports/screenshots under `website/artifacts/`. Do not label planned files or unexecuted checks as complete.

## Failure and revision contract

No unresolved definition gap exists for this local unit. Named future outputs and environment access remain execution prerequisites. Live publication, real receiver/mailbox access, business/asset approval and human translation review remain separately gated by the decisions record.

Repair ordinary defects under this contract and retain failed attempts. For material changes to objectives, structure/public contracts, dependencies or acceptance, follow the plan's complete-package revision procedure, validate shared consumers and record autonomous acceptance within existing authority before affected work. Continue unaffected eligible work. Mark this unit completed only when its output and required checks satisfy the accepted contract.
