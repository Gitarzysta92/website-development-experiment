import { defineConfig } from 'astro/config';
import node from '@astrojs/node';

export default defineConfig({
  output: 'static',
  adapter: node({ mode: 'standalone' }),
  trailingSlash: 'always',
  server: { host: '127.0.0.1', port: 4321 },
  build: { inlineStylesheets: 'auto' },
});
